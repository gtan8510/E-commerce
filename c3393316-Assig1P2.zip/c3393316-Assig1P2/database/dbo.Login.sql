﻿CREATE TABLE [dbo].[Login] (
    [Id]       INT           NOT NULL,
    [UserName] VARCHAR (50)  NULL,
    [Password] NVARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

