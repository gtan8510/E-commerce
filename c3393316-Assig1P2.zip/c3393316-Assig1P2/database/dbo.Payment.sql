﻿CREATE TABLE [dbo].[Payment] (
    [PaymentID]    NVARCHAR (50)  NOT NULL,
    [CustomerName] NVARCHAR (MAX) NULL,
    [Address]      NVARCHAR (MAX) NULL,
    [PostCode]     INT            NULL,
    [MobileNumber] BIGINT         NULL,
    [PaymentMode]  NVARCHAR (50)  NULL,
    PRIMARY KEY CLUSTERED ([PaymentID] ASC)
);

