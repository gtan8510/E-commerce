﻿CREATE TABLE [dbo].[Postage] (
    [Id]           INT            NOT NULL,
    [PostageName]  NVARCHAR (50)  NULL,
    [PostageEmail] NVARCHAR (MAX) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

