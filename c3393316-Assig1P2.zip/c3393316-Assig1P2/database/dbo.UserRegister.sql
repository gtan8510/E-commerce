﻿CREATE TABLE [dbo].[UserRegister] (
    [Id]              INT            NOT NULL,
    [Username]        NVARCHAR (50)  NULL,
    [Password]        NVARCHAR (50)  NULL,
    [ConfirmPassword] NVARCHAR (50)  NULL,
    [Email]           NVARCHAR (MAX) NULL,
    [FullName]        NVARCHAR (MAX) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

