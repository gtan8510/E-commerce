﻿CREATE TABLE [dbo].[AddProduct] (
    [Id]            NVARCHAR (50)  NOT NULL,
    [ProductName]   NVARCHAR (MAX) NULL,
    [Price]         INT            NULL,
    [SellingPrice]  INT            NULL,
    [Brand]         NVARCHAR (50)  NULL,
    [Category]      NCHAR (100)    NULL,
    [SubCategory]   NCHAR (100)    NULL,
    [Size]          NVARCHAR (50)  NULL,
    [Description]   NVARCHAR (MAX) NULL,
    [ProductDetail] NVARCHAR (MAX) NULL,
    [MaterialsCare] NVARCHAR (MAX) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

