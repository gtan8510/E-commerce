﻿CREATE TABLE [dbo].[OrderStatus] (
    [OrderID]     NVARCHAR (50) NOT NULL,
    [OrderStatus] NVARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([OrderID] ASC)
);

