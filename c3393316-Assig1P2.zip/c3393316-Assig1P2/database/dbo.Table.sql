﻿CREATE TABLE [dbo].[Contact]
(
	[ContactID] NVARCHAR(50) NOT NULL PRIMARY KEY, 
    [Name] NVARCHAR(MAX) NULL, 
    [Email] NVARCHAR(MAX) NULL, 
    [PhoneNumber] BIGINT NULL, 
    [Subject] NVARCHAR(MAX) NULL, 
    [Message] NVARCHAR(MAX) NULL
)
