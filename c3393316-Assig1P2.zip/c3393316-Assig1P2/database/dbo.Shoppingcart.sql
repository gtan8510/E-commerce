﻿CREATE TABLE [dbo].[Shoppingcart] (
    [Id]       INT            NOT NULL,
    [UserName] NVARCHAR (50)  NULL,
    [Email]    NVARCHAR (50)  NULL,
    [Address]  NVARCHAR (MAX) NULL,
    [Password] NVARCHAR (50)  NULL,
    [Role]     NVARCHAR (50)  NULL,
    [FullName] NVARCHAR (MAX) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

