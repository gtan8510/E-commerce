﻿CREATE TABLE [dbo].[PurchaseHistory] (
    [OrderItemId] INT            NOT NULL,
    [OrderId]     NVARCHAR (MAX) NULL,
    [Productname] VARCHAR (MAX)  NULL,
    [Quantity]    INT            NULL,
    [OrderDate]   DATETIME2 (7)  NULL,
    [OrderStatus] NVARCHAR (MAX) NULL,
    PRIMARY KEY CLUSTERED ([OrderItemId] ASC)
);

