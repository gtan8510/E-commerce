﻿CREATE TABLE [dbo].[Cart] (
    [CartID]        INT    NOT NULL,
    [ProductCount]  INT    NULL,
    [TotalPrice]    BIGINT NULL,
    [DiscountPrice] BIGINT NULL,
    PRIMARY KEY CLUSTERED ([CartID] ASC)
);

