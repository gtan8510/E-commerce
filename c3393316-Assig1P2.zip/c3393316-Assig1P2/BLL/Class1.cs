﻿using DAL;

namespace BLL
{
    public class Class1
    {
    }
    public class CLSBussLayer
    {
        ClsDataLayer objDAL = new ClsDataLayer();
        public void InsertUser(string _name, string _Address, string _Email)
        {
            objDAL.InsertData(_name, _Address, _Email);
        }
        public object SelectUser()
        {
            return objDAL.SelectData();
        }
    }
}
