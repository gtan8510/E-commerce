﻿using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;

namespace ECommerceProject
{
    public class OrderStatus
    {
        private string Received;
        private string Shipped;
        private string Notreceived;
        private string Cancelled;
    }
}