﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ECommerceProject
{
    public partial class AddGender : System.Web.UI.Page
    {
    SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\AddProduct.mdf;Integrated Security=True");


        protected void Page_Load(object sender, EventArgs e)
        {
            BindGenderRepeater();
        }

        private void BindGenderRepeater()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString2"].ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("Select * from [tblGender]", con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        rptrGender.DataSource = dt;
                        rptrGender.DataBind();
                    }
                }
            }

        }
        
protected void btnAddGender_Click(object sender, EventArgs e)
        {

            string ins = "insert into [tblGender](GenderName) values('" + txtAddGender.Text + "')";
            SqlCommand com = new SqlCommand(ins, con);
            con.Open();
            com.ExecuteNonQuery();

            txtAddGender.Text = string.Empty;
            Response.Write("<script> alert('Gender added successfully ') </script>");
            con.Close();

            txtAddGender.Focus();
        }
    }
    }
