﻿using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;

namespace ECommerceProject
{
    public class guest
    {
        public Product Product
        {
            get => default;
            set
            {
            }
        }

        public void ViewProduct()
        {
            throw new System.NotImplementedException();
        }
    }
}