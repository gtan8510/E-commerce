﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

namespace ECommerceProject
{
    public partial class AddProduct : System.Web.UI.Page
    {
        string a;
        public static String CS = ConfigurationManager.ConnectionStrings["ConnectionString2"].ConnectionString;
        SqlConnection con = new SqlConnection(CS);
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            FuImg01.SaveAs(Request.PhysicalApplicationPath + "./ProductImages/" + FuImg01.FileName.ToString());
            a = "ProductImages/" + a + FuImg01.FileName.ToString();

           
           
            string ins = "insert into [Products](ProductName, UnitPrice, Quantity, Description, ImagePath) values('" + txtProductName.Text + "', '" + txtSellPrice.Text + "', '" + txtQuantity.Text + "', '" + txtDescription.Text + "', '" + a.ToString() + "' )";
            SqlCommand com = new SqlCommand(ins, con);
            con.Open();
            com.ExecuteNonQuery();
            con.Close();
            Response.Redirect("AdminHome.aspx");
        }
    }
}