﻿using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;

namespace ECommerceProject
{
    public class Admin
    {
        private string UserName;
        private string Email;
        private string FullName;

        public Product Product
        {
            get => default;
            set
            {
            }
        }

        public void AddProduct()
        {
            throw new System.NotImplementedException();
        }

        public void EditProduct()
        {
            throw new System.NotImplementedException();
        }

        public void DeleteProduct()
        {
            throw new System.NotImplementedException();
        }
    }
}