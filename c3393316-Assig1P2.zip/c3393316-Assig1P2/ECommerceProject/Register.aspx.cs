﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;

namespace ECommerceProject
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void RegisterButton_Click(object sender, EventArgs e)
        {
            if (isformvalid())
            {
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyECommerceDB"].ConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into tblUsers(Username, Password, Email, Name) values('" + TextUserName.Text + "','" + TextPassword.Text + "','" + TextEmail.Text + "','" + TextFullName.Text + "')", con);
                    cmd.ExecuteNonQuery();

                    Response.Write("<script> alert('Registration successfully done'); </script>");
                    con.Close();
                }
            }
        }

        private bool isformvalid()
        {
            if (TextUserName.Text == "")
            {
                Response.Write("<script> alert('username not valid'); </script>");
                    return false;
            }
            else if(TextPassword.Text== "")
            {
                Response.Write("<script> alert('Password not valid'); </script>");
                return false;
            }
            else if(TextPassword.Text != TextCPassword.Text)
            {
                Response.Write("<script> alert('Password not valid'); </Script>");
                return false;
            }
            else if(TextEmail.Text == "")
            {
                Response.Write("<script> alert('email not valid'); </script>");
                return false;
            }
            else if(TextFullName.Text == "")
            {
                Response.Write("<script> alert('Name not valid') </script>");
                return false;

            }
            return true;
        }
    }
}