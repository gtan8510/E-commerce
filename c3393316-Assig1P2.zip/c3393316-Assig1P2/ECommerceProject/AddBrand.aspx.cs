﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ECommerceProject
{
    public partial class AddBrand : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\AddProduct.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            BindBrandRepeater();
        }

        private void BindBrandRepeater()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString2"].ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("Select * from [tblBrands]", con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        rptrBrand.DataSource = dt;
                        rptrBrand.DataBind();
                    }
                }
            }
          
        }

        protected void btnAddBrand_Click(object sender, EventArgs e)
        {
            string ins = "insert into [tblBrands](Name) values('" + txtBrand.Text + "')";
            SqlCommand com = new SqlCommand(ins, con);
            con.Open();
            com.ExecuteNonQuery();
            con.Close();
            Response.Redirect("AdminHome.aspx");
        }
    }
}