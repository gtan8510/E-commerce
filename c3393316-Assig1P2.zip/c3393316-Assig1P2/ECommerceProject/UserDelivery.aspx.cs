﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;


namespace ECommerceProject
{
    public partial class UserDelivery : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnRegisterAddress_Click(object sender, EventArgs e)
        {
            CLSBussLayer objBLL = new CLSBussLayer();
            objBLL.InsertUser(TextUserName.Text, TextAddress.Text, TextEmail.Text);
            GridView1.DataSource = objBLL.SelectUser();
            GridView1.DataBind();
        
        }
    }
}