﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ECommerceProject
{
    public partial class ProductDescription : System.Web.UI.Page
    {
        public static String CS = ConfigurationManager.ConnectionStrings["ConnectionString2"].ConnectionString;
        SqlConnection con = new SqlConnection(CS);
        int id;
        int qty;
        string ProductName, Description, UnitPrice, Quantity, ImagePath;
        
        protected void b2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Payment.aspx");
        }

        protected void Page_Load(Object sender, EventArgs e)
        {
            if (Request.QueryString["id"] == null)
            {
                Response.Redirect("UserDisplay.aspx");
            }
            else
            {
                id = Convert.ToInt32(Request.QueryString["id"].ToString());
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Select * from [Products]where id=" + id + "";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                dl.DataSource = dt;
                dl.DataBind();
                con.Close();

            }
            qty = get_qty(id);

            if (qty == 0)
            {
                l2.Visible = false;
                t1.Visible = false;


                b1.Visible = false;
                l1.Text = "There is no available quantity";
            }
        }
        protected void b1_Click(object sender, EventArgs e)
        {// should redirect to the viewcart page with cookies
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from [Products] where id=" + id + "";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                ProductName = dr["ProductName"].ToString();
                Description = dr["Description"].ToString();
                UnitPrice = dr["UnitPrice"].ToString();
                Quantity = dr["Quantity"].ToString();
                ImagePath = dr["ImagePath"].ToString();
            }
            con.Close();
            try
            {
                if (Convert.ToInt32(t1.Text) > Convert.ToInt32(Quantity))
                {
                    l1.Text = "Please enter lower quantity";
                }
                else
                {
                    l1.Text = "Total Price is: $" + Convert.ToString((Convert.ToInt32(UnitPrice) * Convert.ToInt32(t1.Text)));
                    b2.Visible = true;


                    if (Request.Cookies == null)
                    {
                        Response.Cookies["aa"].Value = ProductName.ToString() + "," + Description.ToString() + "," + UnitPrice.ToString() + "," + Quantity.ToString() + "," + ImagePath.ToString() + "," + id.ToString();
                        Response.Cookies["aa"].Expires = DateTime.Now.AddDays(1);
                    }
                    else
                    {
                        Response.Cookies["aa"].Value = Request.Cookies["aa"].Value + "|" + ProductName.ToString() + "," + Description.ToString() + "," + UnitPrice.ToString() + "," + Quantity.ToString() + "," + ImagePath.ToString() + "," + id.ToString();
                        Response.Cookies["aa"].Expires = DateTime.Now.AddDays(1);
                    }
                }
            }
            catch
            {
                l1.Text = "please enter some quantity";
            }
            /*
            SqlCommand cmd1 = con.CreateCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "update [Products] set Quantity = Quantity - " + t1.Text + " where id=" + id;
            cmd1.ExecuteNonQuery();
            Response.Redirect("ProductDescription.aspx?id" + id.ToString());
            */
        }

        public int get_qty(int id)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from [Products] where id=" + id + "";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                qty = Convert.ToInt32(dr["Quantity"].ToString());
            }
            return qty;
        }
            

        }



    }
