﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ECommerceProject
{
    public partial class AdminRegister : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\AdminRegistration.mdf;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
           
        }

        protected void btnRegister_Click1(object sender, EventArgs e)
        {
            //inserting the register data to database
            string ins = "insert into [AdminRegistration](Username, Password, Email) values ('" + TextUserName.Text + "', '" + TextPassword.Text + "', '" + TextEmail.Text + "')";
            SqlCommand com = new SqlCommand(ins, con);
            con.Open();
            com.ExecuteNonQuery();
            con.Close();
            Response.Redirect("AdminLogIn.aspx");
        }
    }
}