﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace ECommerceProject.Models
{
    public class ProductDatabaseInitializer: DropCreateDatabaseIfModelChanges<ProductContext>
    {
        protected override void Seed(ProductContext context)
        {
            GetCategories().ForEach(c => context.Categories.Add(c));
            GetProducts().ForEach(p => context.Products.Add(p));
        }

        private static List<Category> GetCategories()
        {
            var categories = new List<Category> {
                new Category
                {
                    CategoryID = 1,
                    CategoryName = "Shirt"
                },
                new Category
                {
                    CategoryID = 2,
                    CategoryName = "Denim"
                },
                new Category
                {
                    CategoryID = 3,
                    CategoryName = "Outer"
                },
                new Category
                {
                    CategoryID = 4,
                    CategoryName = "Pants"
                },
          
            };

            return categories;
        }

        private static List<ProductModel> GetProducts()
        {
            var products = new List<ProductModel> {
                new ProductModel
                {
                    ProductID = 1,
                    ProductName = "Batik",
                    Description = "Batik",
                    ImagePath="Batik.png",
                    UnitPrice = 22.50,
                    CategoryID = 1
               },
                new ProductModel
                {
                    ProductID = 2,
                    ProductName = "Black Tanktop",
                    Description = "Black Tanktop",
                    ImagePath="blacktop.jfif",
                    UnitPrice = 15.95,
                     CategoryID = 1
               },
                new ProductModel
                {
                    ProductID = 3,
                    ProductName = "Black Sweatshirt",
                    Description = "Black Sweatshirt",
                    ImagePath="blackwoman.jpeg",
                    UnitPrice = 32.99,
                    CategoryID = 1
                },
                new ProductModel
                {
                    ProductID = 4,
                    ProductName = "Blue demim",
                    Description = "Blue Denim",
                    ImagePath="bluedenim.jpg",
                    UnitPrice = 17.95,
                    CategoryID = 2
                },
                new ProductModel
                {
                    ProductID = 5,
                    ProductName = "Korean shirt",
                    Description = "Korean shirt",
                    ImagePath="flowershirt.jpeg",
                    UnitPrice = 22.95,
                    CategoryID = 1
                },
                new ProductModel
                {
                    ProductID = 6,
                    ProductName = "Green shirt",
                    Description = "Green shirt",
                    ImagePath="greenshirt.jfif",
                    UnitPrice = 25.00,
                    CategoryID = 1
                },
                new ProductModel
                {
                    ProductID = 7,
                    ProductName = "Jeans denim",
                    Description = "Jeans denim",
                    ImagePath="jeansdenim.jfif",
                    UnitPrice = 4.95,
                    CategoryID = 2
                },
                new ProductModel
                {
                    ProductID = 8,
                    ProductName = "loose tanktop",
                    Description = "loose tanktop",
                    ImagePath="loosetanktop.jfif",
                    UnitPrice = 7.95,
                    CategoryID = 1
                },
                new ProductModel
                {
                    ProductID = 9,
                    ProductName = "Pink Shirt",
                    Description = "Pink shirt",
                    ImagePath="pinkshirt.jfif",
                    UnitPrice = 12.95,
                    CategoryID = 1
                },
                new ProductModel
                {
                    ProductID = 10,
                    ProductName = "Army shorts",
                    Description = "army shorts",
                    ImagePath="shorts.jfif",
                    UnitPrice = 15.00,
                    CategoryID = 3
                },
                new ProductModel
                {
                    ProductID = 11,
                    ProductName = "White shorts",
                    Description = "white shorts",
                    ImagePath="whiteshorts.jfif",
                    UnitPrice = 6.00,
                    CategoryID = 3
                },
                new ProductModel
                {
                    ProductID = 12,
                    ProductName = "White tanktop",
                    Description = "white tanktop",
                    ImagePath="whitetanktop.jfif",
                    UnitPrice = 9.00,
                    CategoryID = 1
                }
            };

            return products;
        }
    }

}