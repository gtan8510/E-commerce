﻿using Microsoft.Build.Framework.XamlTypes;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;


namespace ECommerceProject.Models
{
    public class ProductContext: DbContext
    {
        public ProductContext()
           : base("ECommerceProject")
        {
        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<ProductModel> Products { get; set; }
        public DbSet<CartItem> ShoppingCartItems { get; set; }
    }
}