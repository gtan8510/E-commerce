﻿using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;

namespace ECommerceProject
{
    public class Product
    {
        private string ID;
        private string Name;
        private int Price;
        private int SellingPrice;
        private string Brand;
        private string Category;
        private string Subcategory;
        private int Size;
        private string Description;
        private string ProductDetail;

        public int? ProductID { get; internal set; }
        public int? CategoryID { get; internal set; }
        public int? UnitPrice { get; internal set; }
    }
}