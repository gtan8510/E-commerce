﻿using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;

namespace ECommerceProject
{
    public class Customer
    {
        private string UserName;
        private int PhoneNumber;
        private string Email;
        private string Fullname;

        public Product Product
        {
            get => default;
            set
            {
            }
        }

        public OrderStatus OrderStatus
        {
            get => default;
            set
            {
            }
        }

        public payment payment
        {
            get => default;
            set
            {
            }
        }

        public cart cart
        {
            get => default;
            set
            {
            }
        }

        public void Register()
        {
            throw new System.NotImplementedException();
        }

        public void Login()
        {
            throw new System.NotImplementedException();
        }

        public void SearchProduct()
        {
            throw new System.NotImplementedException();
        }

        public void Purchase()
        {
            throw new System.NotImplementedException();
        }
    }
}