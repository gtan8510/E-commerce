﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ECommerceProject
{
    
    public partial class Payment : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }



        protected void btnPayNow_Click(object sender, EventArgs e)
        {
            Response.Redirect("EndingPage.aspx");
        }

        protected void btnPayNow_Click1(object sender, EventArgs e)
        {
            Response.Redirect("EndingPage.aspx");
        }

        protected void btnCard_Click(object sender, EventArgs e)
        {
            Response.Redirect("EndingPage.aspx");
        }
    }
}