﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace ECommerceProject
{
    public partial class AdminPostageOption : System.Web.UI.Page
    {

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\web programming\ECommerceProject\ECommerceProject\App_Data\AdminPostage.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}