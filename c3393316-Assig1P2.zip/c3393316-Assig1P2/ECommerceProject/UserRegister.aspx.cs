﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ECommerceProject
{
    public partial class UserRegister : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\UserRegister.mdf;Integrated Security=True"); 
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }



        protected void btnregister_Click(object sender, EventArgs e)
        {

            string ins = "insert into [userRegister](Username, Password, ConfirmPassword, Email, FullName) values ('" + TextUserName.Text + "', '" + TextPassword.Text + "', '" + TextCPassword.Text + "', '" + TextEmail.Text + "', '" + TextFullName.Text + "')";
            SqlCommand com = new SqlCommand(ins, con);
            con.Open();
            com.ExecuteNonQuery();
            con.Close();
            Response.Redirect("Login.aspx");

        }

    }
}
