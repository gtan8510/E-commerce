﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace ECommerceProject
{
    public partial class AdminLogIn : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\AdminRegistration.mdf;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            //take the username and password from the adminregistration database
            string check = "Select count(*) from [AdminRegistration] where Username = '" + TextUserName.Text + "' and Password = '" + TextPassword.Text + "' ";
            SqlCommand com = new SqlCommand(check, con);
            con.Open();
            int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
            con.Close();
            if (temp == 1)
            {
                Response.Redirect("AdminHome.aspx");
            }
            else
            {
                lblAlert.ForeColor = System.Drawing.Color.Red;
                lblAlert.Text = "your Username or password is invalid";
            }
        }

        protected void btnLogIn_Click(object sender, EventArgs e)
        {
          
        }
    }
}