﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ECommerceProject
{
    public partial class deleteCart : System.Web.UI.Page
    {
        public static String CS = ConfigurationManager.ConnectionStrings["ConnectionString2"].ConnectionString;
        SqlConnection con = new SqlConnection(CS);
        string s;
        string t;
        string[] a = new string[6];
        int id;
        string ProductName, Description, UnitPrice, Quantity, ImagePath;
        int count = 0;
        int product_id, qty;
        protected void Page_Load(object sender, EventArgs e)
        {
            id = Convert.ToInt32(Request.QueryString["id"].ToString());
            DataTable dt = new DataTable();
            dt.Rows.Clear();
            dt.Columns.AddRange(new DataColumn[7] { new DataColumn("ProductName"), new DataColumn("Description"),
            new DataColumn("UnitPrice"), new DataColumn("Quantity"), new DataColumn("ImagePath"), new DataColumn("id"), new DataColumn("product_id")});

            if (Request.Cookies["aa"] != null)
            {
                s = Convert.ToString(Request.Cookies["aa"].Value);
                string[] strArr = s.Split('|');
                for(int i = 0; i < strArr.Length; i++)
                {
                    t = Convert.ToString(strArr[i].ToString());
                    string[] strArr1 = t.Split(',');
                    for(int j = 0; j < strArr1.Length; j++)
                    {
                        a[j] = strArr1[j].ToString();

                    }
                    dt.Rows.Add(a[0].ToString(), a[1].ToString(), a[2].ToString(), a[3].ToString(), a[4].ToString(), i.ToString(), a[5].ToString());
                }
            }

            count = 0;
            foreach (DataRow dr in dt.Rows)
            {
                if(count == id)
                {
                    product_id = Convert.ToInt32(dr["product_id"].ToString());
                    qty = Convert.ToInt32(dr["Quantity"].ToString());
                }
                count = count + 1;
            }
            count = 0;
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update [Products] set Quantity +" + qty + " where id=" + product_id;
            cmd.ExecuteNonQuery();
            con.Close();


            dt.Rows.RemoveAt(id);

            Response.Cookies["aa"].Expires = DateTime.Now.AddDays(-1);
            Response.Cookies["aa"].Expires = DateTime.Now.AddDays(-1);

            foreach(DataRow dr in dt.Rows)
            {
                ProductName = dr["ProductName"].ToString();
                Description = dr["Description"].ToString();
                UnitPrice = dr["unitPrice"].ToString();
                Quantity = dr["Quantity"].ToString();
                ImagePath = dr["ImagePath"].ToString();
                product_id = Convert.ToInt32(dr["product_id"].ToString());

                count = count + 1;

                if(count == 1)
                {
             Response.Cookies["aa"].Value = ProductName.ToString() + "," + Description.ToString() + "," + UnitPrice.ToString() + "," + Quantity.ToString() + "," + ImagePath.ToString() + "," +product_id.ToString();
             Response.Cookies["aa"].Expires = DateTime.Now.AddDays(1);
                }
                else
                {
            Response.Cookies["aa"].Value = Request.Cookies["aa"].Value + "|" + ProductName.ToString() + "," + Description.ToString() + "," + UnitPrice.ToString() + "," + Quantity.ToString() + "," + ImagePath.ToString() + "," + product_id.ToString();
        Response.Cookies["aa"].Expires = DateTime.Now.AddDays(1);
                }
            }
            Response.Redirect("ViewCart.aspx");

        }
    }
}