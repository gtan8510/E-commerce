﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
    public class Class1
    {
        
    }
    public class ClsDataLayer
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\web programming\\c3393316 - Assignment1\\ECommerceProject\\App_Data\\AddProduct.mdf;Integrated Security=True");
        public void InsertData(string _name, string _Address, string _Email)
        {
           
            SqlDataAdapter sqlAdp = new SqlDataAdapter("Insert into [tblUserInfo](Name, Address, EmailID) values('" + _name + "', '" + _Address + "', '" + _Email +  "')",con);
            DataTable DT = new DataTable();
            sqlAdp.Fill(DT);
        }
        public object SelectData()
        {
            SqlDataAdapter SQLAdp = new SqlDataAdapter("Select * from [tblUserInfo]", con);
            DataTable DT = new DataTable();
            SQLAdp.Fill(DT);
            return DT;
        }
    }
}